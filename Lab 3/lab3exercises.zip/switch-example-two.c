#include<stdio.h>

int main()
{
    int x;
    x=3;
    switch(x)
    {
    case 1:
        printf("\n One");
        break;
    case 2:
        printf("\n Two");
        break;
    case 3:
        printf("\n Three");
        break;
    case 4:
        printf("\n Four");
        break;
    default:
        printf("\n Bye");
    }
    return 0;
}
