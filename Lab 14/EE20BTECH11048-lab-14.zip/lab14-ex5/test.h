void print_hello();
void ask_name(char *name);
void print_name(char *name);
